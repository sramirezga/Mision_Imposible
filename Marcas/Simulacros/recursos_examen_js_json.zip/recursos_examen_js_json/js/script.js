// Archivo de práctica.
// Aquí van las funciones del examen.
// Están vacías a propósito para que practiques tú.

// Login: leer datos/usuarios.json, comprobar usuario y password.
// Si es admin/admin -> administrador.html
// Si es otro usuario correcto -> catalogo.html
// Si no coincide -> alert de error.
async function login() {

}

// Administrador: al cargar la página, leer usuarios.json y mostrar id + usuario.
async function cargarUsuarios() {

}

// Administrador: leer el id del input, buscar usuario y mostrar su perfil.
async function verPerfil() {

}

// Catálogo: al cargar la página, leer instrumentos.json y mostrar tabla.
async function cargarInstrumentos() {

}

// Catálogo: mostrar todos los instrumentos.
async function verTodos() {

}

// Catálogo: mostrar solo instrumentos con posición par.
async function filtrarPar() {

}

// Catálogo: leer precio del input y mostrar instrumentos con precio menor.
async function filtrarPrecio() {

}

// Salir: volver al index.html.
function salir() {

}
